/*Withdraw algorithm*/
UPDATE ACCOUNT a
SET a.Balance = a.Balance - (
  SELECT SUM(d.AMMOUNT)
  FROM Withdraw d
  WHERE d.Bcode = a.Bcode AND d.Ac = 0
);
