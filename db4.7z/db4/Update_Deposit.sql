/*Deposit algorithm*/
UPDATE ACCOUNT a
SET a.Balance = a.Balance + (
  SELECT SUM(d.AMMOUNT)
  FROM DEPOSIT d
  WHERE d.Bcode = a.Bcode AND d.Ac = 0
);

