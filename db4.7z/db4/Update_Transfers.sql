/*Transfers algorithms*/
/*example for trade number 130*/

UPDATE ACCOUNT
SET Balance = Balance - (
  SELECT Ammount 
  FROM TRANSFERS 
  WHERE ACCOUNT.Bcode = TRANSFERS.Bcode AND TRANSFERS.Tnum = 144
)
WHERE Balance >= (
  SELECT Ammount 
  FROM TRANSFERS 
  WHERE ACCOUNT.Bcode = TRANSFERS.Bcode AND TRANSFERS.Tnum = 144
);

UPDATE ACCOUNT
SET Balance = Balance + (
    SELECT TRANSFERS.Ammount
    FROM TRANSFERS
    WHERE ACCOUNT.Bcode = TRANSFERS.PerCode
      AND TRANSFERS.Tnum = 144
)
WHERE EXISTS (
    SELECT 1
    FROM TRANSFERS
    WHERE ACCOUNT.Bcode = TRANSFERS.PerCode
      AND TRANSFERS.Tnum = 144
);




/*if the transfer is possible */

update TRANSFERS 
SET  AC = 1
Where Tnum = 144 ;

/*if the transfer is not possible */

update TRANSFERS 
SET  AC = 0
Where Tnum = 144 ;